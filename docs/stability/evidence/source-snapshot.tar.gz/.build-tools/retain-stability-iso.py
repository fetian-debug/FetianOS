import json
from pathlib import Path
import shutil
root=Path.cwd(); evidence=root/'docs/stability/evidence/iso-attempt-1'
evidence.mkdir(exist_ok=True)
for desktop in ('sway','hyprland'):
    source=root/('.build-tools/stability-iso-'+desktop)
    target=evidence/desktop
    if target.exists():raise FileExistsError(target)
    shutil.copytree(source,target)
    print(desktop+' diagnostics retained',flush=True)
record=dict(source_revision='4b41effbc9451c05aac19ea52c346e52df414a1c',run_id=44505284369,
            desktop='both',publish=False,publication_job='skipped',
            sway='image verification and UEFI serial/live-account probe passed',
            hyprland='ISO created; embedded-payload verification failed; no boot acceptance',
            graphical_login=False,installation=False,hardware=False,daily_use_acceptance=False)
(evidence/'observations.json').write_text(json.dumps(record,indent=2)+'\n')
