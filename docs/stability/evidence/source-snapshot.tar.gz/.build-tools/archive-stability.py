"""Archive completed experiment records without discarding failed cases."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile
root=Path.cwd()/'docs/stability/evidence'
for argument in sys.argv[1:]:
    folder=(root/argument).resolve()
    assert folder.is_relative_to(root.resolve())
    summary=json.loads((folder/'summary.json').read_text())
    paths=sorted(folder.glob('run-*.json'))
    assert len(paths)==summary['completed']
    index=[dict(name=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in paths]
    archive=folder/'runs.tar.gz';assert not archive.exists()
    with tarfile.open(archive,'w:gz') as stream:
        for path in paths:stream.add(path,arcname=path.name)
    with tarfile.open(archive,'r:gz') as stream:
        for entry in index:assert hashlib.sha256(stream.extractfile(entry['name']).read()).hexdigest()==entry['sha256']
    (folder/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
    failed={entry['report'] for entry in summary['failures']}
    for path in paths:
        if path.name not in failed:path.unlink()
    print(str(folder.relative_to(root))+': '+str(len(index))+' exact records archived; failed cases also kept as plain JSON',flush=True)
