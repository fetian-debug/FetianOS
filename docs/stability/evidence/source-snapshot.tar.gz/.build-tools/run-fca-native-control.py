"""Control WSL executable I/O with identical binaries on Linux temporary storage."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
root=Path.cwd(); output=root/'docs/stability/evidence/linux-fca-control'
output.mkdir(exist_ok=False)
records=[]
with tempfile.TemporaryDirectory(prefix='fetian-stability-binaries-') as directory:
    binary=Path(directory); hashes={}
    for source in (root/'system/fetian-fca/target/release').glob('fetian-*'):
        if not source.is_file() or source.suffix=='.d':continue
        target=binary/source.name;shutil.copyfile(source,target);target.chmod(0o755)
        digest=hashlib.sha256(source.read_bytes()).hexdigest()
        assert digest==hashlib.sha256(target.read_bytes()).hexdigest()
        hashes[source.name]=digest
    env=dict(os.environ,FCA_BIN_DIR=str(binary),TMPDIR='/tmp')
    (output/'plan.json').write_text(json.dumps(dict(binary_hashes=hashes,scope='Same binaries, workload, seeds and deadlines; change only executable filesystem location. No FCA source changes.'),indent=2)+'\n')
    commands=[('process',[sys.executable,'system/fetian-fca/tests/process_tests.py']),
              ('deterministic',[sys.executable,'system/fetian-fca/validation/lab.py','deterministic','--include-expiry','--output',str(output/'deterministic')]),
              ('security',[sys.executable,'system/fetian-fca/validation/lab.py','security','--output',str(output/'security')]),
              ('boundaries',[sys.executable,'system/fetian-fca/validation/security.py','--output',str(output/'boundaries')]),
              ('stress',[sys.executable,'system/fetian-fca/validation/lab.py','stress','--runs','1000','--seed','2090','--output',str(output/'stress')])]
    for name,command in commands:
        started=time.monotonic()
        with (output/(name+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=2400)
        records.append(dict(name=name,command=command,exit_code=result.returncode,seconds=time.monotonic()-started))
        (output/'results.json').write_text(json.dumps(records,indent=2)+'\n')
        print(name+': '+str(result.returncode),flush=True)
print('Linux-binary control finished.',flush=True)
