import hashlib
import json
from pathlib import Path
import shutil
import tarfile
root=Path.cwd(); evidence=root/'docs/stability/evidence/hosted-fca'
evidence.mkdir(exist_ok=True)
for artifact in sorted((root/'.build-tools/stability-hosted-fca').iterdir()):
    for source in artifact.iterdir():
        assert source.is_dir()
        target=evidence/source.name;target.mkdir(exist_ok=False)
        runs=sorted(source.glob('run-*.json'));index=[]
        for path in source.iterdir():
            assert path.is_file()
            if not path.name.startswith('run-'):shutil.copyfile(path,target/path.name)
        if runs:
            summary=json.loads((source/'summary.json').read_text())
            assert len(runs)==summary['completed']
            with tarfile.open(target/'runs.tar.gz','w:gz') as stream:
                for path in runs:
                    index.append(dict(name=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
                    stream.add(path,arcname=path.name)
            (target/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
            for failed in summary['failures']:shutil.copyfile(source/failed['report'],target/failed['report'])
        print(source.name+': hosted evidence retained',flush=True)
