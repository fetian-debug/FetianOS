import os
from pathlib import Path
import subprocess
import sys
root=Path.cwd()
env=dict(os.environ, CARGO_HOME=str(root/'.build-tools/cargo'), RUSTUP_HOME=str(root/'.build-tools/rustup'), RUSTUP_TOOLCHAIN='1.89.0')
env['PATH']=str(root/'.build-tools/cargo/bin')+':/usr/bin:/bin'
env['TMPDIR']='/tmp'
raise SystemExit(subprocess.run([sys.executable, 'scripts/stability-check.py', *sys.argv[1:]], env=env).returncode)
