import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time
root=Path.cwd(); tools=root/'.build-tools/audit'; output=root/'docs/stability/evidence/dependency-audit'
output.mkdir(exist_ok=False)
archive=tools/'cargo-audit-x86_64-unknown-linux-musl-v0.23.0.tgz'
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
assert digest=='4f01c74ed84b2dffd0b1d37012a62cdf2a92c96e25bdf8eec7fcc0d4d3eb7811'
with tarfile.open(archive) as stream:
    members=[member for member in stream if Path(member.name).name=='cargo-audit' and member.isfile()]
    assert len(members)==1
    executable=tools/'cargo-audit'; executable.write_bytes(stream.extractfile(members[0]).read()); executable.chmod(0o755)
record=dict(version='0.23.0', asset_sha256=digest, source='https://github.com/rustsec/rustsec/releases/tag/cargo-audit/v0.23.0', results=[])
env=dict(os.environ, CARGO_HOME=str(root/'.build-tools/cargo'), RUSTUP_HOME=str(root/'.build-tools/rustup'),RUSTUP_TOOLCHAIN='1.89.0')
env['PATH']=str(root/'.build-tools/cargo/bin')+':/usr/bin:/bin'
for name,lock in [('native',root/'Cargo.lock'),('fca',root/'system/fetian-fca/Cargo.lock')]:
    command=[str(executable),'audit','--file',str(lock),'--json','--db',str(tools/'advisory-db')]
    result=subprocess.run(command,cwd=root,env=env,text=True,capture_output=True,timeout=180)
    (output/(name+'.json')).write_text(result.stdout)
    (output/(name+'.stderr.log')).write_text(result.stderr)
    record['results'].append(dict(name=name,command=command,exit_code=result.returncode,lock_sha256=hashlib.sha256(lock.read_bytes()).hexdigest()))
    print(name+' audit exit '+str(result.returncode),flush=True)
try:record['advisory_revision']=subprocess.check_output(['git','-C',str(tools/'advisory-db'),'rev-parse','HEAD'],text=True).strip()
except subprocess.CalledProcessError:record['advisory_revision']=None
record['recorded_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
(output/'tool-and-results.json').write_text(json.dumps(record,indent=2)+'\n')
