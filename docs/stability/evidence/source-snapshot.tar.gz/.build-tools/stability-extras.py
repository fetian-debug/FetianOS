import json
import os
from pathlib import Path
import subprocess
import sys
import time
root=Path.cwd(); output=root/'docs/stability/evidence/supplemental'
output.mkdir(exist_ok=False)
env=dict(os.environ,FCA_BIN_DIR=str(root/'system/fetian-fca/target/release'),TMPDIR='/tmp')
commands=[('fca-boundaries',[sys.executable,'system/fetian-fca/validation/security.py','--output',str(output/'fca-boundaries')]),
          ('live-telemetry',[str(root/'target/release/fetian-health-rs'),'--json'])]
records=[]
for name,command in commands:
    started=time.monotonic()
    with (output/(name+'.log')).open('w') as log:
        result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    records.append(dict(name=name,command=command,exit_code=result.returncode,seconds=time.monotonic()-started))
    (output/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name+': '+str(result.returncode),flush=True)
