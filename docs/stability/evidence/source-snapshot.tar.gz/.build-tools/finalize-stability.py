import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

root=Path.cwd(); evidence=root/'docs/stability/evidence'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
base='06aa67fc4a1ee25d37211c288d0fa0630c9b44dc'
protected=['system/fetian-fca','Cargo.toml','Cargo.lock','.github/workflows/iso-release.yml']
assert not subprocess.check_output(['git','diff','--name-only',base,'--',*protected]).strip()
release=read(evidence/'release-preservation.json')
assert release['id']==450149449 and release['tag_name']=='preview-7-1'
assets={entry['name']:entry for entry in release['assets']}
assert assets['fetianOS-0.1.0-x86_64.iso.part001']['digest']=='sha256:e9c1e61471eccc35c37042ea7a0ecc53cc080f3ecbc44eb4a06532b81316f3c3'
assert assets['fetianOS-0.1.0-x86_64.iso.part002']['digest']=='sha256:41d222868563d15be4f3382b13ee7529b2b828eed5f32807d4df166a958b1a22'
paths=['apps/fetian-files/preferences.py','desktop/hyprland/fetian_shell.py',
       'desktop/hyprland/bin/fetian-hyprland-session','system/boot/airootfs/usr/bin/fetian-sway-session',
       'system/boot/live_setup.py','system/boot/airootfs/usr/lib/systemd/user/fetian-bluetooth-agent.service',
       'system/boot/airootfs/usr/lib/systemd/user/fetian-sway-idle.service',
       'desktop/hyprland/airootfs/usr/lib/systemd/user/fetian-idle.service',
       'desktop/hyprland/airootfs/usr/lib/systemd/user/fetian-shell.service',
       'scripts/release-artifacts.py','scripts/stability-check.py','scripts/verify-stability.py',
       'tests/test_stability.py','tests/test_iso_payload.py','.github/workflows/source-checks.yml','.gitattributes',
       '.build-tools/run-stabilization.py','.build-tools/run-fca-native-control.py',
       '.build-tools/stability-audit.py','.build-tools/stability-extras.py',
       '.build-tools/archive-stability.py','.build-tools/retain-hosted-stability.py',
       '.build-tools/retain-stability-iso.py','.build-tools/finalize-stability.py']
archive_path=evidence/'source-snapshot.tar.gz'
index=dict(scope='Final source snapshot collected after validation; original baseline product is reconstructible at the base commit. This is not an exact historical snapshot of every intermediate runner version.', files=[])
for name in paths:
    data=(root/name).read_bytes()
    index['files'].append(dict(path=name,sha256=hashlib.sha256(data).hexdigest(),
                              canonical_sha256=hashlib.sha256(data.replace(b'\r\n',b'\n')).hexdigest()))
if not archive_path.exists():
    with tarfile.open(archive_path,'w:gz') as archive:
        for name in paths:archive.add(root/name,arcname=name)
else:
    with tarfile.open(archive_path,'r:gz') as archive:
        for entry in index['files']:assert hashlib.sha256(archive.extractfile(entry['path']).read()).hexdigest()==entry['sha256'],entry['path']
(evidence/'source-index.json').write_text(json.dumps(index,indent=2)+'\n')
summary=dict(status='NOT_ACCEPTED_FOR_DAILY_USE',stable=False,base_revision=base,defects=7,
             recorded_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
             fca_implementation_unchanged=True,published_release_unchanged=True,
             release_check_scope='GitHub metadata/digests only; no new download or rebuilding of published ISO bytes',
             physical_target=read(root/'docs/stability/hardware-target.json'),
             stress={name:read(evidence/path/'summary.json') for name,path in [('wsl_original','final/fca-stress'),('wsl_linux_executables','linux-fca-control/stress'),('hosted','hosted-fca/stress')]},
             critical_open_gates=['physical HP boot/device acceptance','graphical sign-in/lock/logout and crash recovery',
                                  'installed-system upgrade/cleanup/reboot','24-hour soak and idle/memory-growth measurements',
                                  'Secure Boot and physical suspend/resume'],
             unresolved=['WSL timing failures retained; executable relocation did not eliminate them','Initial GTK preview timeout has no proven root cause'],
             candidate_runs=[])
payload_log=(evidence/'iso-attempt-2/source-job.log').read_text(encoding='utf-8-sig')
assert 'Ran 130 tests' in payload_log and 'OK (skipped=' not in payload_log
assert 'FETIAN_LARGE_ISO_TEST: 1' in payload_log
summary['payload_regressions']=dict(hosted_tests=130,hosted_skips=0,local_tests=130,local_skips=2,
                                    large_fixture_bytes=2**31+65536,source_job=135615681941)
for attempt in sorted(evidence.glob('iso-attempt-*')):
    if (attempt/'run.json').exists():
        run=read(attempt/'run.json')
        summary['candidate_runs'].append(dict(id=run['id'],source=run['head_sha'],status=run['status'],conclusion=run['conclusion']))
(evidence/'stability-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for path in sorted((root/'docs/stability').rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or path==evidence/'manifest.json':continue
    data=path.read_bytes();mode='raw' if path.suffix in ('.gz','.ppm','.png') else 'crlf-to-lf'
    files[path.relative_to(root).as_posix()]=dict(mode=mode,sha256=hashlib.sha256(data if mode=='raw' else data.replace(b'\r\n',b'\n')).hexdigest())
(evidence/'manifest.json').write_text(json.dumps(dict(schema_version=1,files=files,attestation='Local unsigned checksums; no independent peer-review claim.'),indent=2)+'\n')
print('Final source snapshot, preserved-release checks and evidence manifest retained.',flush=True)
